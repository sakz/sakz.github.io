[PAC](https://pac.itzmx.com/)
=======
本项目主要介绍如何利用国外VPS搭建多协议代理服务。

GFW 封锁了 HTTP/Socks5 代理，HTTP 代理是关键词过滤，Socks5 代理则是封锁协议。不过某些特殊的低端口并没有这么处理，已知的有 21，25。

20端口已经被封杀，21端口目前会被限速400Kbps，换算后约合50KB/S，建议使用25端口，不限速。

[这里](https://pac.itzmx.com/) 提供了我在 [linode](https://pac.itzmx.com/abc.pac) 上搭建的公共代理。


搭建代理服务器
==============
在 25 端口搭建 http/https 代理。


Ubuntu: 
-------
apt-get install squid
curl https://pac.itzmx.com/squid/ubuntu-squid.conf > /etc/squid3/squid.conf
/etc/init.d/squid restart


CentOS:
-------
setenforce 0
ulimit -n 1024000
echo "* soft nofile 1024000" >> /etc/security/limits.conf
echo "* hard nofile 1024000" >> /etc/security/limits.conf
/etc/init.d/postfix stop
chkconfig --level 2345 postfix off
yum -y install squid
wget -O /etc/squid/squid.conf https://pac.itzmx.com/squid/centos-squid.conf
/etc/init.d/squid restart
chkconfig --level 2345 squid on

然后使用 [PAC](https://pac.itzmx.com/abc.pac) 生成 PAC 即可。


出处：http://bbs.itzmx.com/thread-8815-1-1.html
